var searchData=
[
  ['hiba_20lista_0',['Hiba lista',['../bug.html',1,'']]]
];
