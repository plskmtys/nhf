var searchData=
[
  ['listaelem_0',['ListaElem',['../lista_8h.html#aecc7aa80a85efb3789bb0888e9fe4c78',1,'lista.h']]]
];
