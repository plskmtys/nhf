var searchData=
[
  ['architecture_5fid_0',['ARCHITECTURE_ID',['../build_2CMakeFiles_23_826_84_2CompilerIdC_2CMakeCCompilerId_8c.html#aba35d0d200deaeb06aee95ca297acb28',1,'ARCHITECTURE_ID:&#160;CMakeCCompilerId.c'],['../cmake-build-debug_2CMakeFiles_23_826_84_2CompilerIdC_2CMakeCCompilerId_8c.html#aba35d0d200deaeb06aee95ca297acb28',1,'ARCHITECTURE_ID:&#160;CMakeCCompilerId.c']]]
];
