var searchData=
[
  ['keres_0',['keres',['../lista_8c.html#afa8367e962630f7be6b4de81435d685d',1,'keres(ListaElem *eleje, char *needle):&#160;lista.c'],['../lista_8h.html#a30b9f80ee8e039c47b3b35d422341bc4',1,'keres(ListaElem *eleje, char *keresett):&#160;lista.c']]]
];
