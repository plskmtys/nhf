var searchData=
[
  ['olvas_0',['olvas',['../menu_8c.html#a7511e5e75a7389a4fa84531bb6ed2acb',1,'olvas(char *s, size_t len):&#160;menu.c'],['../menu_8h.html#a7511e5e75a7389a4fa84531bb6ed2acb',1,'olvas(char *s, size_t len):&#160;menu.c']]]
];
