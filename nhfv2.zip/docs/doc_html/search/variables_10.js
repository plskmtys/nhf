var searchData=
[
  ['view_5foptions_0',['view_options',['../menu_8c.html#ab5a2e1feec075bb78bf0d16d086a7bdf',1,'view_options:&#160;menu.c'],['../menu_8h.html#ab5a2e1feec075bb78bf0d16d086a7bdf',1,'view_options:&#160;menu.c']]]
];
