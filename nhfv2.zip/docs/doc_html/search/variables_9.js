var searchData=
[
  ['name_0',['name',['../structcontact.html#a7f4d1d227388f7406467291f7fb71e68',1,'contact']]],
  ['name_5foptions_1',['name_options',['../menu_8c.html#af02989f4d440945afd45cd55b033c915',1,'name_options:&#160;menu.c'],['../menu_8h.html#af02989f4d440945afd45cd55b033c915',1,'name_options:&#160;menu.c']]],
  ['newc_5foptions_2',['newc_options',['../menu_8c.html#ae5bf3baca6e2c99ee74f9a9b63bdb175',1,'newc_options:&#160;menu.c'],['../menu_8h.html#ae5bf3baca6e2c99ee74f9a9b63bdb175',1,'newc_options:&#160;menu.c']]],
  ['next_3',['next',['../structDebugmallocEntry.html#a7ebf7cb15f24577c59e05768d8f9ffc5',1,'DebugmallocEntry::next'],['../structListaElem.html#adaf8d19e14207ecc2f0f3f53631f2210',1,'ListaElem::next']]],
  ['note_4',['note',['../structcontact.html#a70d54b296a64542b4def4249ca0029fc',1,'contact']]]
];
