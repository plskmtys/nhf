var searchData=
[
  ['size_0',['size',['../structDebugmallocEntry.html#a854352f53b148adc24983a58a1866d66',1,'DebugmallocEntry']]],
  ['street_5fno_1',['street_no',['../structaddress.html#a8e3e42780c382ccd428d9b66c41c5361',1,'address']]],
  ['suffix_2',['suffix',['../structfullname.html#ade4c7e9e52c9a7d14f082e3a4157cedc',1,'fullname']]]
];
