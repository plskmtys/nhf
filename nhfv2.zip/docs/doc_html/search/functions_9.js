var searchData=
[
  ['main_0',['main',['../build_2CMakeFiles_23_826_84_2CompilerIdC_2CMakeCCompilerId_8c.html#a0ddf1224851353fc92bfbff6f499fa97',1,'main(int argc, char *argv[]):&#160;CMakeCCompilerId.c'],['../cmake-build-debug_2CMakeFiles_23_826_84_2CompilerIdC_2CMakeCCompilerId_8c.html#a0ddf1224851353fc92bfbff6f499fa97',1,'main(int argc, char *argv[]):&#160;CMakeCCompilerId.c'],['../func__test_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main():&#160;func_test.c'],['../main_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main():&#160;main.c']]],
  ['menukiir_1',['menukiir',['../menu_8c.html#a4616510f31e0ce756c2ee7391feccaf9',1,'menukiir(const char **lista):&#160;menu.c'],['../menu_8h.html#a4616510f31e0ce756c2ee7391feccaf9',1,'menukiir(const char **lista):&#160;menu.c']]]
];
