var searchData=
[
  ['olvas_0',['olvas',['../menu_8c.html#a7511e5e75a7389a4fa84531bb6ed2acb',1,'olvas(char *s, size_t len):&#160;menu.c'],['../menu_8h.html#a7511e5e75a7389a4fa84531bb6ed2acb',1,'olvas(char *s, size_t len):&#160;menu.c']]],
  ['org_1',['org',['../structcontact.html#aaea634ea7d6d90ceb5235c07ea8d195f',1,'contact']]],
  ['org_5foptions_2',['org_options',['../menu_8c.html#a213c487e6d1b0bb1127f159c68349ea8',1,'org_options:&#160;menu.c'],['../menu_8h.html#a213c487e6d1b0bb1127f159c68349ea8',1,'org_options:&#160;menu.c']]]
];
