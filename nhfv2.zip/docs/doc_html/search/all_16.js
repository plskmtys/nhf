var searchData=
[
  ['zip_0',['zip',['../structaddress.html#af7e9a6ab6bfcd695641774081343fefe',1,'address']]]
];
