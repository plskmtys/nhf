var searchData=
[
  ['lista_2ec_0',['lista.c',['../lista_8c.html',1,'']]],
  ['lista_2ec_2eo_2ed_1',['lista.c.o.d',['../build_2CMakeFiles_2nhf_8dir_2include_2lista_8c_8o_8d.html',1,'(Globális névtér)'],['../cmake-build-debug_2CMakeFiles_2nhf_8dir_2include_2lista_8c_8o_8d.html',1,'(Globális névtér)']]],
  ['lista_2eh_2',['lista.h',['../lista_8h.html',1,'']]]
];
