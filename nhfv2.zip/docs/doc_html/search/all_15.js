var searchData=
[
  ['writecard_0',['writecard',['../vcard_8c.html#a253aea9b676a965da763797b49588494',1,'writecard(char *filename, contact *out):&#160;vcard.c'],['../vcard_8h.html#a253aea9b676a965da763797b49588494',1,'writecard(char *filename, contact *out):&#160;vcard.c']]]
];
