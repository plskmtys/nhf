var searchData=
[
  ['lista_5ffree_0',['lista_free',['../lista_8c.html#a7beabb037cf9b023775f4c61d4f5c569',1,'lista_free(ListaElem *eleje):&#160;lista.c'],['../lista_8h.html#a7beabb037cf9b023775f4c61d4f5c569',1,'lista_free(ListaElem *eleje):&#160;lista.c']]],
  ['lista_5fkiir_5fshort_1',['lista_kiir_short',['../lista_8c.html#a6d5161ffd4605fe903671277fbd1b9a7',1,'lista_kiir_short(ListaElem *eleje):&#160;lista.c'],['../lista_8h.html#a6d5161ffd4605fe903671277fbd1b9a7',1,'lista_kiir_short(ListaElem *eleje):&#160;lista.c']]],
  ['listahossz_2',['listahossz',['../lista_8c.html#a5c04314c4f81309c505eea03b8e81136',1,'listahossz(ListaElem *elso):&#160;lista.c'],['../lista_8h.html#a1c404904f585cbf4edbc2c8f45337cd9',1,'listahossz(ListaElem *eleje):&#160;lista.c']]]
];
