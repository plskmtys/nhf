var searchData=
[
  ['import_5fall_0',['import_all',['../lista_8c.html#a0578dd7469b833b2b77a71319d35f07b',1,'import_all(ListaElem *eleje):&#160;lista.c'],['../lista_8h.html#a0578dd7469b833b2b77a71319d35f07b',1,'import_all(ListaElem *eleje):&#160;lista.c']]],
  ['initaddress_1',['InitAddress',['../vcard_8c.html#aad809b0fb4a9bf5139e2089702bade2e',1,'InitAddress(address empty):&#160;vcard.c'],['../vcard_8h.html#aad809b0fb4a9bf5139e2089702bade2e',1,'InitAddress(address empty):&#160;vcard.c']]],
  ['initcontact_2',['InitContact',['../vcard_8c.html#a5a00c12a6910aea3523038a2cc2c72f1',1,'InitContact(contact empty):&#160;vcard.c'],['../vcard_8h.html#a5a00c12a6910aea3523038a2cc2c72f1',1,'InitContact(contact empty):&#160;vcard.c']]],
  ['initname_3',['InitName',['../vcard_8c.html#ac9433bcece7608be618418f5a0a81b7b',1,'InitName(fullname empty):&#160;vcard.c'],['../vcard_8h.html#ac9433bcece7608be618418f5a0a81b7b',1,'InitName(fullname empty):&#160;vcard.c']]]
];
