var searchData=
[
  ['name_0',['name',['../structcontact.html#a7f4d1d227388f7406467291f7fb71e68',1,'contact']]],
  ['name_5foptions_1',['name_options',['../menu_8c.html#af02989f4d440945afd45cd55b033c915',1,'name_options:&#160;menu.c'],['../menu_8h.html#af02989f4d440945afd45cd55b033c915',1,'name_options:&#160;menu.c']]],
  ['namemenu_2',['namemenu',['../menu_8c.html#aed0390265b05e02c2d57bc08d3d61e99',1,'namemenu(contact *c):&#160;menu.c'],['../menu_8h.html#aed0390265b05e02c2d57bc08d3d61e99',1,'namemenu(contact *c):&#160;menu.c']]],
  ['newc_5foptions_3',['newc_options',['../menu_8c.html#ae5bf3baca6e2c99ee74f9a9b63bdb175',1,'newc_options:&#160;menu.c'],['../menu_8h.html#ae5bf3baca6e2c99ee74f9a9b63bdb175',1,'newc_options:&#160;menu.c']]],
  ['next_4',['next',['../structDebugmallocEntry.html#a7ebf7cb15f24577c59e05768d8f9ffc5',1,'DebugmallocEntry::next'],['../structListaElem.html#adaf8d19e14207ecc2f0f3f53631f2210',1,'ListaElem::next']]],
  ['nhf_5',['nhf',['../md__2home_2matyas_2sata_2code_2prog1_2nhf_2nhf_2README.html',1,'']]],
  ['note_6',['note',['../structcontact.html#a70d54b296a64542b4def4249ca0029fc',1,'contact']]],
  ['nth_7',['nth',['../lista_8c.html#ac128b6331a52f48cae150c3db80b217a',1,'nth(ListaElem *eleje, size_t n):&#160;lista.c'],['../lista_8h.html#ac128b6331a52f48cae150c3db80b217a',1,'nth(ListaElem *eleje, size_t n):&#160;lista.c']]]
];
