var searchData=
[
  ['namemenu_0',['namemenu',['../menu_8c.html#aed0390265b05e02c2d57bc08d3d61e99',1,'namemenu(contact *c):&#160;menu.c'],['../menu_8h.html#aed0390265b05e02c2d57bc08d3d61e99',1,'namemenu(contact *c):&#160;menu.c']]],
  ['nth_1',['nth',['../lista_8c.html#ac128b6331a52f48cae150c3db80b217a',1,'nth(ListaElem *eleje, size_t n):&#160;lista.c'],['../lista_8h.html#ac128b6331a52f48cae150c3db80b217a',1,'nth(ListaElem *eleje, size_t n):&#160;lista.c']]]
];
