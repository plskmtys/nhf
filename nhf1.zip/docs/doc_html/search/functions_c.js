var searchData=
[
  ['readcard_0',['readcard',['../vcard_8c.html#a854dfd243a430c4ef180711747d13841',1,'readcard(char *filename, contact *c):&#160;vcard.c'],['../vcard_8h.html#a854dfd243a430c4ef180711747d13841',1,'readcard(char *filename, contact *c):&#160;vcard.c']]]
];
