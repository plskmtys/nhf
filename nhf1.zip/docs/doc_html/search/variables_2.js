var searchData=
[
  ['city_0',['city',['../structaddress.html#a28ced362b9ded97f50a39e963f29ff04',1,'address']]],
  ['country_1',['country',['../structaddress.html#abea4338dd6b0bb298089ec868b880041',1,'address']]],
  ['county_2',['county',['../structaddress.html#abd49490c86c31a72995abf49fa2d3920',1,'address']]]
];
