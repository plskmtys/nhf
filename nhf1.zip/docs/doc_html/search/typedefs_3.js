var searchData=
[
  ['fullname_0',['fullname',['../vcard_8h.html#a2ec903086cac70bc9e0502dd01fe1fcc',1,'vcard.h']]]
];
