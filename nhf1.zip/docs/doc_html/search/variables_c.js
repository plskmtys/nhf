var searchData=
[
  ['real_5fmem_0',['real_mem',['../structDebugmallocEntry.html#ae241706d126e0114e48ce7c4083d93d1',1,'DebugmallocEntry']]]
];
