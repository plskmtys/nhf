var searchData=
[
  ['c_5fversion_0',['C_VERSION',['../cmake-build-debug_2CMakeFiles_23_826_84_2CompilerIdC_2CMakeCCompilerId_8c.html#adaee3ee7c5a7a22451ea25e762e1d7d5',1,'C_VERSION:&#160;CMakeCCompilerId.c'],['../build_2CMakeFiles_23_826_84_2CompilerIdC_2CMakeCCompilerId_8c.html#adaee3ee7c5a7a22451ea25e762e1d7d5',1,'C_VERSION:&#160;CMakeCCompilerId.c']]],
  ['calloc_1',['calloc',['../debugmalloc_8h.html#ac07b71d27b6b37e81ac3a4c230f5794e',1,'debugmalloc.h']]],
  ['city_2',['city',['../structaddress.html#a28ced362b9ded97f50a39e963f29ff04',1,'address']]],
  ['clear_3',['clear',['../menu_8h.html#ac8bb3912a3ce86b15842e79d0b421204',1,'clear():&#160;menu.c'],['../menu_8c.html#ac8bb3912a3ce86b15842e79d0b421204',1,'clear():&#160;menu.c']]],
  ['cmakeccompilerid_2ec_4',['CMakeCCompilerId.c',['../build_2CMakeFiles_23_826_84_2CompilerIdC_2CMakeCCompilerId_8c.html',1,'(Globális névtér)'],['../cmake-build-debug_2CMakeFiles_23_826_84_2CompilerIdC_2CMakeCCompilerId_8c.html',1,'(Globális névtér)']]],
  ['compiler_5fid_5',['COMPILER_ID',['../build_2CMakeFiles_23_826_84_2CompilerIdC_2CMakeCCompilerId_8c.html#a81dee0709ded976b2e0319239f72d174',1,'COMPILER_ID:&#160;CMakeCCompilerId.c'],['../cmake-build-debug_2CMakeFiles_23_826_84_2CompilerIdC_2CMakeCCompilerId_8c.html#a81dee0709ded976b2e0319239f72d174',1,'COMPILER_ID:&#160;CMakeCCompilerId.c']]],
  ['contact_6',['contact',['../structcontact.html',1,'contact'],['../vcard_8h.html#aae3737f80f092987fab3029a6eeda7a1',1,'contact:&#160;vcard.h']]],
  ['contactmenu_7',['contactmenu',['../menu_8c.html#aab7e0e15ab3bc1ca9dc8970c06fa5e32',1,'contactmenu(contact *c):&#160;menu.c'],['../menu_8h.html#aab7e0e15ab3bc1ca9dc8970c06fa5e32',1,'contactmenu(contact *c):&#160;menu.c']]],
  ['contextmenu_8',['contextmenu',['../menu_8c.html#ae92fa9aa548b28b0b1d48bdfeac140d2',1,'menu.c']]],
  ['country_9',['country',['../structaddress.html#abea4338dd6b0bb298089ec868b880041',1,'address']]],
  ['county_10',['county',['../structaddress.html#abd49490c86c31a72995abf49fa2d3920',1,'address']]]
];
