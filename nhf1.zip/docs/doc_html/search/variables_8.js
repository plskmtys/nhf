var searchData=
[
  ['main_5foptions_0',['main_options',['../menu_8c.html#a3ae317e9dc2b47980a3a8012e7c4b72a',1,'main_options:&#160;menu.c'],['../menu_8h.html#a3ae317e9dc2b47980a3a8012e7c4b72a',1,'main_options:&#160;menu.c']]],
  ['max_5fblock_5fsize_1',['max_block_size',['../structDebugmallocData.html#a5ff6535cb48e89d8b0707e889ba72b0d',1,'DebugmallocData']]],
  ['middle_2',['middle',['../structfullname.html#a4dcf42af6a34f4f4dcffd41247cc3b40',1,'fullname']]]
];
