var searchData=
[
  ['debugmallocdata_0',['DebugmallocData',['../structDebugmallocData.html',1,'']]],
  ['debugmallocentry_1',['DebugmallocEntry',['../structDebugmallocEntry.html',1,'']]]
];
