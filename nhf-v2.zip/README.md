# Telefonkönyv
beadás óta módosítva:
-"összes megtekintése" és "keresés" funkció:
ezek már memóriakezelési hiba nélkül működnek úgy, hogy az eredeti struktúrákkal dolgoznak és nem másolatokkal.
-a program lefut a -Wall és a -Werror használata mellett is.

