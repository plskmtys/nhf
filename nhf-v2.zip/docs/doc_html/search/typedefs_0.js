var searchData=
[
  ['address_0',['address',['../vcard_8h.html#ae9f0eeeac531882122ce4345e0305740',1,'vcard.h']]]
];
