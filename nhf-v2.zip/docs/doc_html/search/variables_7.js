var searchData=
[
  ['last_0',['last',['../structfullname.html#a28444f4f4b6fadbfb28c0f6afec6f555',1,'fullname']]],
  ['line_1',['line',['../structDebugmallocEntry.html#a05ef0c4dbeec4fc8ccb225de9c26d896',1,'DebugmallocEntry']]],
  ['logfile_2',['logfile',['../structDebugmallocData.html#af5ff893eedb28514f6f69c3687ca893b',1,'DebugmallocData']]]
];
