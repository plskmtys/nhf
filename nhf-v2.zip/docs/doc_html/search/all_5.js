var searchData=
[
  ['edit_5fcontact_0',['edit_contact',['../menu_8c.html#a1d5786c1cd6a4210f7a7cb6965a89599',1,'edit_contact(contact *c, char *next):&#160;menu.c'],['../menu_8h.html#a1d5786c1cd6a4210f7a7cb6965a89599',1,'edit_contact(contact *c, char *next):&#160;menu.c']]],
  ['elore_5fbeszur_1',['elore_beszur',['../lista_8c.html#a31bda40c7ed5666c71d25ee7f0698b23',1,'elore_beszur(ListaElem *eleje, contact adat):&#160;lista.c'],['../lista_8h.html#a31bda40c7ed5666c71d25ee7f0698b23',1,'elore_beszur(ListaElem *eleje, contact adat):&#160;lista.c']]],
  ['email_2',['email',['../structcontact.html#afea8840490132feb2abc7118243c9805',1,'contact']]],
  ['expr_3',['expr',['../structDebugmallocEntry.html#aa8f5b6d2256e18de50b9a17b5e3cda3b',1,'DebugmallocEntry']]]
];
