var searchData=
[
  ['readcard_0',['readcard',['../vcard_8c.html#a854dfd243a430c4ef180711747d13841',1,'readcard(char *filename, contact *c):&#160;vcard.c'],['../vcard_8h.html#a854dfd243a430c4ef180711747d13841',1,'readcard(char *filename, contact *c):&#160;vcard.c']]],
  ['readme_2emd_1',['README.md',['../README_8md.html',1,'']]],
  ['real_5fmem_2',['real_mem',['../structDebugmallocEntry.html#ae241706d126e0114e48ce7c4083d93d1',1,'DebugmallocEntry']]],
  ['realloc_3',['realloc',['../debugmalloc_8h.html#a54df243d89c451240697d7d3afb5663f',1,'debugmalloc.h']]]
];
