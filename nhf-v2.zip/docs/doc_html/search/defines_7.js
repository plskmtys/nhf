var searchData=
[
  ['platform_5fid_0',['PLATFORM_ID',['../build_2CMakeFiles_23_826_84_2CompilerIdC_2CMakeCCompilerId_8c.html#adbc5372f40838899018fadbc89bd588b',1,'PLATFORM_ID:&#160;CMakeCCompilerId.c'],['../cmake-build-debug_2CMakeFiles_23_826_84_2CompilerIdC_2CMakeCCompilerId_8c.html#adbc5372f40838899018fadbc89bd588b',1,'PLATFORM_ID:&#160;CMakeCCompilerId.c']]]
];
