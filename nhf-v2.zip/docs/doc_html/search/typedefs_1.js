var searchData=
[
  ['contact_0',['contact',['../vcard_8h.html#aae3737f80f092987fab3029a6eeda7a1',1,'vcard.h']]]
];
