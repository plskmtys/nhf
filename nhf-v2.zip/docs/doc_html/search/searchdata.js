var indexSectionsWithContent =
{
  0: "_abcdefghiklmnoprstuvwz",
  1: "acdfl",
  2: "cdflmrv",
  3: "abcdegiklmnorsvw",
  4: "abcefhilmnoprstuvz",
  5: "acdfl",
  6: "d",
  7: "_acdfhmprs",
  8: "hn"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enumvalues",
  7: "defines",
  8: "pages"
};

var indexSectionLabels =
{
  0: "Összes",
  1: "Adatszerkezetek",
  2: "Fájlok",
  3: "Függvények",
  4: "Változók",
  5: "Típusdefiníciók",
  6: "Enumeráció-értékek",
  7: "Makródefiníciók",
  8: "Oldalak"
};

