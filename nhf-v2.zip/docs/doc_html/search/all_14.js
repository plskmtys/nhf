var searchData=
[
  ['vcard_2ec_0',['vcard.c',['../vcard_8c.html',1,'']]],
  ['vcard_2ec_2eo_2ed_1',['vcard.c.o.d',['../build_2CMakeFiles_2nhf_8dir_2include_2vcard_8c_8o_8d.html',1,'(Globális névtér)'],['../cmake-build-debug_2CMakeFiles_2nhf_8dir_2include_2vcard_8c_8o_8d.html',1,'(Globális névtér)']]],
  ['vcard_2eh_2',['vcard.h',['../vcard_8h.html',1,'']]],
  ['vegere_5fbeszur_3',['vegere_beszur',['../lista_8c.html#a213dbbfba64a6ce43911dccda6209e95',1,'vegere_beszur(ListaElem *eleje, contact adat):&#160;lista.c'],['../lista_8h.html#ac8cc37a60e3a1922a36ab2713c8b9dbf',1,'vegere_beszur(ListaElem *elso, contact uj):&#160;lista.c']]],
  ['view_5foptions_4',['view_options',['../menu_8c.html#ab5a2e1feec075bb78bf0d16d086a7bdf',1,'view_options:&#160;menu.c'],['../menu_8h.html#ab5a2e1feec075bb78bf0d16d086a7bdf',1,'view_options:&#160;menu.c']]]
];
