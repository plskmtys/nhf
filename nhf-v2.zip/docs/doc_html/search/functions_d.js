var searchData=
[
  ['sor_5folvas_0',['sor_olvas',['../lista_8c.html#af87bbaf8085626b08bc86e6527426be8',1,'sor_olvas():&#160;lista.c'],['../lista_8h.html#af87bbaf8085626b08bc86e6527426be8',1,'sor_olvas():&#160;lista.c']]],
  ['straddr_1',['straddr',['../vcard_8c.html#a64efb829d5f2dfc7caa7c985e7abbb17',1,'straddr(address *a):&#160;vcard.c'],['../vcard_8h.html#a64efb829d5f2dfc7caa7c985e7abbb17',1,'straddr(address *a):&#160;vcard.c']]],
  ['strfn_2',['strfn',['../vcard_8c.html#ab971e3c8f8e9e33762559a4593bb6d09',1,'strfn(fullname *n):&#160;vcard.c'],['../vcard_8h.html#ab971e3c8f8e9e33762559a4593bb6d09',1,'strfn(fullname *n):&#160;vcard.c']]]
];
