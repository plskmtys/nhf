var searchData=
[
  ['vegere_5fbeszur_0',['vegere_beszur',['../lista_8c.html#a213dbbfba64a6ce43911dccda6209e95',1,'vegere_beszur(ListaElem *eleje, contact adat):&#160;lista.c'],['../lista_8h.html#ac8cc37a60e3a1922a36ab2713c8b9dbf',1,'vegere_beszur(ListaElem *elso, contact uj):&#160;lista.c']]]
];
