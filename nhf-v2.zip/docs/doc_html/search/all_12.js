var searchData=
[
  ['tail_0',['tail',['../structDebugmallocData.html#a6a489bd48f708358b171a68acf75de9f',1,'DebugmallocData']]],
  ['title_1',['title',['../structcontact.html#ab01864b8dc1434cb982001720ae5c25c',1,'contact']]]
];
