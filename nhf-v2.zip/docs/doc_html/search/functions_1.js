var searchData=
[
  ['beker_0',['beker',['../menu_8c.html#a1a9c269ab6540db38a98f674fd1c308a',1,'beker(const char *prompt, char *dest, size_t size):&#160;menu.c'],['../menu_8h.html#a1a9c269ab6540db38a98f674fd1c308a',1,'beker(const char *prompt, char *dest, size_t size):&#160;menu.c']]],
  ['beker_5fkeres_1',['beker_keres',['../menu_8c.html#a4afc2c905030cd29adf466414faccd6c',1,'beker_keres(const char *prompt, char *dest, size_t size):&#160;menu.c'],['../menu_8h.html#a4afc2c905030cd29adf466414faccd6c',1,'beker_keres(const char *prompt, char *dest, size_t size):&#160;menu.c']]]
];
