var searchData=
[
  ['getlastitem_0',['GetLastItem',['../lista_8c.html#ad6ebb9c0b839999e94c03db03ad3aa1a',1,'GetLastItem(ListaElem *eleje):&#160;lista.c'],['../lista_8h.html#ad6ebb9c0b839999e94c03db03ad3aa1a',1,'GetLastItem(ListaElem *eleje):&#160;lista.c']]]
];
