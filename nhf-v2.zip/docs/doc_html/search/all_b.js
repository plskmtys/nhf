var searchData=
[
  ['last_0',['last',['../structfullname.html#a28444f4f4b6fadbfb28c0f6afec6f555',1,'fullname']]],
  ['line_1',['line',['../structDebugmallocEntry.html#a05ef0c4dbeec4fc8ccb225de9c26d896',1,'DebugmallocEntry']]],
  ['lista_2ec_2',['lista.c',['../lista_8c.html',1,'']]],
  ['lista_2ec_2eo_2ed_3',['lista.c.o.d',['../build_2CMakeFiles_2nhf_8dir_2include_2lista_8c_8o_8d.html',1,'(Globális névtér)'],['../cmake-build-debug_2CMakeFiles_2nhf_8dir_2include_2lista_8c_8o_8d.html',1,'(Globális névtér)']]],
  ['lista_2eh_4',['lista.h',['../lista_8h.html',1,'']]],
  ['lista_5ffree_5',['lista_free',['../lista_8c.html#a7beabb037cf9b023775f4c61d4f5c569',1,'lista_free(ListaElem *eleje):&#160;lista.c'],['../lista_8h.html#a7beabb037cf9b023775f4c61d4f5c569',1,'lista_free(ListaElem *eleje):&#160;lista.c']]],
  ['lista_5fkiir_5fshort_6',['lista_kiir_short',['../lista_8c.html#a6d5161ffd4605fe903671277fbd1b9a7',1,'lista_kiir_short(ListaElem *eleje):&#160;lista.c'],['../lista_8h.html#a6d5161ffd4605fe903671277fbd1b9a7',1,'lista_kiir_short(ListaElem *eleje):&#160;lista.c']]],
  ['listaelem_7',['ListaElem',['../structListaElem.html',1,'ListaElem'],['../lista_8h.html#aecc7aa80a85efb3789bb0888e9fe4c78',1,'ListaElem:&#160;lista.h']]],
  ['listahossz_8',['listahossz',['../lista_8c.html#a5c04314c4f81309c505eea03b8e81136',1,'listahossz(ListaElem *elso):&#160;lista.c'],['../lista_8h.html#a1c404904f585cbf4edbc2c8f45337cd9',1,'listahossz(ListaElem *eleje):&#160;lista.c']]],
  ['logfile_9',['logfile',['../structDebugmallocData.html#af5ff893eedb28514f6f69c3687ca893b',1,'DebugmallocData']]]
];
