var searchData=
[
  ['vcard_2ec_0',['vcard.c',['../vcard_8c.html',1,'']]],
  ['vcard_2ec_2eo_2ed_1',['vcard.c.o.d',['../build_2CMakeFiles_2nhf_8dir_2include_2vcard_8c_8o_8d.html',1,'(Globális névtér)'],['../cmake-build-debug_2CMakeFiles_2nhf_8dir_2include_2vcard_8c_8o_8d.html',1,'(Globális névtér)']]],
  ['vcard_2eh_2',['vcard.h',['../vcard_8h.html',1,'']]]
];
